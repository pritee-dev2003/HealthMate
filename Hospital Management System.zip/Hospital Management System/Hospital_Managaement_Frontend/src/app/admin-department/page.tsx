import AdminDepartment from '@/Components/Admin/AdminDepartment'
import Layout from '@/Components/Common/Layout'
import React from 'react'

const page = () => {
  return (
   <Layout>
<AdminDepartment/>
   </Layout>
  )
}

export default page