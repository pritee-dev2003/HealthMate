import Appointment from '@/Components/Patient/Appointment'
import TestComponents from '@/Components/TestComponents'
import React from 'react'

const page = () => {
  return (
    <div>
    <TestComponents/> 
    <Appointment/>
    </div>
  )
}

export default page
