"use client"
import React from 'react'
import "bootstrap/dist/js/bootstrap.bundle.js"
const Partners = () => {
  return (
    <>
      
      <div className='row '>
        <div className="col-lg-10 py-5 mx-auto">
          <div className="row mb-3">
            <div className="col-sm-6 mx-auto ">
              <h1 className='my-color2 fw-bold text-center fs-1' >Partners who support us</h1>
        <div className='strip my-4 mx-auto'></div>
        <p className='my-color1 mb-3 text-center awp' > Lets know moreel necessitatibus dolor asperiores illum possimus sint voluptates incidunt molestias nostrum laudantium. Maiores porro cumque quaerat.</p>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-10 mx-auto">
              <div className="row">
                <div className="col-md-6 bg-danger">
                  <div className="div"></div>
                </div>
                <div className="col-md-6 bg-info">
                  <div className="div"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default Partners
