"use client"
import { DoctorWrap } from '@/HOC/DoctorWrap'
import React from 'react' 
const DoctorAppointmentsList = () => {
  return (
    <div>
     <h1>DoctorAppointmentsList</h1> 
    </div>
  )
}

export default DoctorWrap(DoctorAppointmentsList) 
